"""Align only the post-exit AV batch geometry; keep real hidden/KV compact."""
from contextlib import contextmanager
from unittest.mock import patch

import torch
from transformers.models.qwen3_vl import modeling_qwen3_vl as qm

from ..qwen3vl_svh_numerical_repair.engine import AlignedExecution, original


def restore_query_rows(probabilities, text_positions, original_length):
    if probabilities.shape[-2] != len(text_positions):
        raise ValueError('Query position count mismatch')
    if len(set(text_positions)) != len(text_positions) or any(p < 0 or p >= original_length for p in text_positions):
        raise ValueError('Invalid original query mapping')
    full = probabilities.new_zeros((*probabilities.shape[:-2], original_length, probabilities.shape[-1]))
    indices = torch.as_tensor(text_positions, device=probabilities.device)
    full.index_copy_(-2, indices, probabilities)
    return full, indices


class AVAlignedExecution(AlignedExecution):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.av_row_alignment = []

    @contextmanager
    def context(self):
        eager = qm.eager_attention_forward

        def aligned(module, q, k, v, attention_mask=None, **kwargs):
            if not (self.physical and self.step == 0 and getattr(module, 'layer_idx', -1) >= 22):
                return eager(module, q, k, v, attention_mask, **kwargs)
            native_matmul = torch.matmul
            call = 0

            def matmul(a, b, *args, **kw):
                nonlocal call
                call += 1
                if call != 2:
                    return native_matmul(a, b, *args, **kw)
                # Only AV gets transient zero query rows. QK/softmax, all
                # projections, norm/MLP and persistent KV still use real rows.
                assert a.dtype == b.dtype == torch.bfloat16
                assert a.shape[-2:] == (len(self.text), self.n) and b.shape[-2] == self.n
                full, ix = restore_query_rows(a, self.text.tolist(), self.n)
                out = native_matmul(full, b, *args, **kw)
                self.av_row_alignment.append(dict(layer=module.layer_idx, step=0,
                    real_queries=a.shape[-2], temporary_AV_queries=full.shape[-2], keys=a.shape[-1],
                    heads=a.shape[-3], head_dim=b.shape[-1],
                    zero_query_rows=self.n-len(self.text), image_hidden_rows=0, persistent_dummy_KV=0,
                    probability_buffer_bytes=full.numel()*full.element_size(),
                    output_buffer_bytes=out.numel()*out.element_size(),
                    extra_AV_flops=2*a.shape[0]*a.shape[-3]*(self.n-len(self.text))*a.shape[-1]*b.shape[-1]))
                return out.index_select(-2, ix)

            with patch.object(torch, 'matmul', matmul):
                out = eager(module, q, k, v, attention_mask, **kwargs)
            assert call == 2, 'Pinned eager must execute exactly QK and AV'
            return out

        with patch.object(qm, 'eager_attention_forward', aligned), super().context():
            yield self

    def audit(self):
        out = super().audit()
        out['AV_query_row_alignment'] = self.av_row_alignment
        out['extra_AV_query_alignment_flops'] = sum(r['extra_AV_flops'] for r in self.av_row_alignment)
        out['actual_language_matrix_flops'] += out['extra_AV_query_alignment_flops']
        return out


def generate(model, processor, inputs, layout, condition='C', **kwargs):
    assert condition == 'C'
    with patch.object(original, 'Execution', AVAlignedExecution):
        return original.generate(model, processor, inputs, layout, condition, **kwargs)
